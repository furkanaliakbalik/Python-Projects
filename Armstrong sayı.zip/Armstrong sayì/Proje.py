def kup(sayi):
    sayi = sayi*sayi*sayi
    return sayi

G_Sayi = int(input("3 Basamaklı Sayı Giriniz ör(345):"))

birlerBasamagi = int(G_Sayi % 10)
onlarBasamagi = int((G_Sayi - birlerBasamagi)/10%10)
yuzlerBasamagi = int(G_Sayi/100)

print("\nYüzler Basamağı:",yuzlerBasamagi,"\tOnlar Basamağı:",onlarBasamagi,"\tBirler Basamağı:",birlerBasamagi,"\n")

sayi1 = kup(birlerBasamagi)
sayi2 = kup(onlarBasamagi)
sayi3 = kup(yuzlerBasamagi)

print(yuzlerBasamagi,"Küpü:",sayi1,"\t",onlarBasamagi,"Küpü:",sayi2,"\t",birlerBasamagi,"Küpü:",sayi3,"\n")

print(sayi1,"+",sayi2,"+",sayi3,"=",sayi1+sayi2+sayi3,"\n")
if (sayi1 + sayi2 + sayi3 == G_Sayi):
    print(G_Sayi," bir Armstrong sayıdir.")
else:
    print(G_Sayi," bir Armstrong sayı değildir.")