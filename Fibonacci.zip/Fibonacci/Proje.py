Sayi = 0
Sayi1 = 1

Girilensayi=int(input("\nTerim Sayısını Giriniz:"))

print(Sayi)
print(Sayi1)
for i in range(2, Girilensayi):
    Sayi3 =Sayi1 + Sayi
    Sayi = Sayi1
    Sayi1 = Sayi3
    print(Sayi3)