	#hesap isiminde bir değişken oluşturuyoruz ve içine başlangıç değeri olarak 10.000 para katıyoruz
hesap =int(input("Başlangıç Bakyenizi Belirtiniz Örneğin=10000:"))
while True:
    print("\n**********İşlemler**********")
    print("1.Para Çekme")
    print("2.Para Yatırma")
    print("3.Bakiye Sorma")
    print("4.Çıkış")
    
    islem=int(input("Lütfen İşlem Tipini Seçiniz:"))
    print("*"*20)
    if islem == 1:
        cekilecek=int(input("Çekmek İstediğiniz Tutarı Giriniz:"))
        if cekilecek <= hesap:
            print("Paranızı Kutudan Alınız")
            hesap=hesap-cekilecek
            print("Kalan Bakiyeniz= ", hesap)
        else :
            print("Bakiyeniz Yetersiz...")
    
    elif islem == 2 :
        yatirilacak=int(input("Yatırmak İstediğiniz Tutarı Giriniz="))
        hesap=hesap+yatirilacak
        print("Mevcut Bakiyeniz= ", hesap)
    
    elif islem == 3 :
        print("Mevcut Bakiyeniz= ", hesap)
    
    elif islem == 4 :
        print("İyi Günler Dileriz")
        break
    else:
        print("Lütfen Geçerli Bir İşlem Giriniz")
