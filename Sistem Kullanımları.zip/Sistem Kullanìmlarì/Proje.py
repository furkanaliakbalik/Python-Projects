import psutil
print("\n")
print("*"*50)

bellek = psutil.virtual_memory()
toplam_bellek = bellek.total / (1024 ** 3)
kullanilan_bellek = bellek.used / (1024 ** 3) 
yuzde_kullanim = bellek.percent
print("Toplam Bellek:", toplam_bellek, "GB")
print("Kullanılan Bellek:", kullanilan_bellek, "GB")
print("Bellek Kullanım Yüzdesi:", yuzde_kullanim, "%")

print("*"*50)

cpu_yuzdesi = psutil.cpu_percent()
print("CPU Kullanım Yüzdesi:", cpu_yuzdesi)

print("*"*50)

disk = psutil.disk_usage('/')
toplam_disk = disk.total / (1024 ** 3)  
kullanilan_disk = disk.used / (1024 ** 3)  
yuzde_kullanim = disk.percent
print("Toplam Disk Alanı:", toplam_disk, "GB")
print("Kullanılan Disk Alanı:", kullanilan_disk, "GB")
print("Disk Kullanım Yüzdesi:", yuzde_kullanim, "%")

print("*"*50)
print("\n")


