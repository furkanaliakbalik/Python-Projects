import tkinter as tk
from time import strftime

def time():
    string = strftime('%H:%M:%S %p')
    lbl.config(text=string)
    lbl.after(1000, time)

# Pencere oluştur
root = tk.Tk()
root.title("Canlı Saat")

# Saat etiketi oluştur
lbl = tk.Label(root, font=('calibri', 40, 'bold'), background='black', foreground='green')

# Etiketi yerleştir
lbl.pack(anchor='center')

# Tarih etiketi oluştur
date_lbl = tk.Label(root, font=('calibri', 16, 'bold'), background='black', foreground='white')
date_lbl.pack(side='bottom')

# Saati güncelle
time()

# Tarihi güncelle
date_string = strftime('%A, %B %d, %Y')
date_lbl.config(text=date_string)

root.mainloop()
