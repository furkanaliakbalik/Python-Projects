Merhaba,Kodları kopyalayıp kendi kodunuza ekleyebilirsiniz.
Kodların hiçbir yerinde kendi adım yazmamaktadır, 
yani içiniz rahat bir şekilde kodları okumadan kopyalayıp kendi kodunuz gibi kullanabilirsiniz.

EMEĞİME KARŞILIK HESAPLARIMI TAKİP ETMENİZ YETERLİ

Linkedin https://www.linkedin.com/in/furkanaliakbalik/

Markam   https://tr.linkedin.com/company/rootcodewave?trk=public_post_follow-view-profile

Github   https://github.com/furkanaliakbalik
